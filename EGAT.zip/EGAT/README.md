本代码为基于《EGAT- Edge-Featured Graph Attention Network》[EGAT: Edge-Featured Graph Attention Network | Artificial Neural Networks and Machine Learning – ICANN 2021 (acm.org)](https://dl.acm.org/doi/abs/10.1007/978-3-030-86362-3_21)文章的Pytorch实现。

### 环境要求

- Python 3.10
- Pytorch 2.0.1
- DGL ：[Deep Graph Library (dgl.ai)](https://www.dgl.ai/pages/start.html)

### 项目结构及相关函数说明

#### layers.py——EGAT模型层级阐述

- ```
  class MultiInputMLPUpdate(nn.Module) 
  ```

  - 在 PyTorch 中实现多输入 MLP（多层感知器）更新模型类，用于处理图神经网络中的边特征更新。

  -  `__init__` 中定义了三个输入层（分别对应不同的输入特征维度），一个隐藏层和一个输出层，并将所有层都转移到 CUDA 设备上进行计算加速。
  - `update_edge` 用于更新每条边特征。它接收一个边数据集（`edges`）作为输入，并提取出与每条边相关的源节点、目标节点以及边自身的特征。然后，通过对应的线性层对这些特征进行变换，并将变换后的结果相加得到一个综合特征向量 `h`。
  - `forward` 首先打印整个图结构，将其转换到 GPU 上，然后应用 `update_edge` 函数来更新所有边的特征，最后返回更新后的边特征 `graph.edata['e_out']`，即表示每条边的新特征表示。这个返回值通常会在训练或推断过程中用作损失函数计算或者进一步的图神经网络操作。

- ```
  class EGATLayer(nn.Module)
  ```

  - 该类是基于图注意力网络（GAT）设计的自定义层，用于处理节点特征和边特征。在初始化时，它根据输入参数设置不同线性层、参数矩阵，并初始化这些参数。
  - 在 `forward` 函数中,计算基于节点和边特征的不同注意力权重。通过应用消息传递函数更新节点信息，其中考虑了邻居节点和边的信息，并使用Leaky ReLU激活函数。
  - 使用更新后的节点特征再次进行线性变换以获得节点相关的注意力权重，并结合原始边特征来计算新的边注意力权重。
  - 将更新后的节点和边特征组合起来，然后传入一个名为 `MultiInputMLPUpdate` 的多输入多层感知器（MLP）类以进一步更新边特征。
  - 最后将 MLP 更新后的边特征与可选的偏置项相加，得到最终的边特征输出。

- ```
  class BottleneckLayer(nn.Module)
  ```

  - 同时对节点特征和边特征进行线性变换,作为信息瓶颈或者特征压缩的中间层。
  - 它通过全连接层对节点特征和边特征进行降维或升维操作，然后使用 ELU 激活函数进行非线性变换。

- ```
  class MLPPredictor(nn.Module)
  ```

  - 定义了一个简单的多层感知器（MLP）预测模型，用于从输入数据中预测输出。
  - 通常用在网络的最后一层，将之前处理过的特征转换为输出类别概率分布。

- ```
  class MergeLayer(nn.Module)
  ```

  - 合并来自不同来源或多阶段处理后的特征向量，例如，在一个阶段中有多个特征流时，该层可以通过全连接层将这些特征融合成一个新的、维度更低的特征向量。

#### models.py——将各层级整合

- `EGAT` 类定义了一个基于 GAT（图注意力网络）的自定义模型，该模型结合了瓶颈层、多输入GAT层、MLP预测器以及合并层等多个组件。
- 初始化方法 `__init__` 中：
  - 定义参数：节点特征数 `node_feats`，边特征数 `edge_feats`，隐藏层特征数 `f_h` 和 `f_e`，lambda 参数 `lamda`，注意力头数量 `num_heads`，dropout比例 `dropout`，预测层隐藏层大小 `pred_hid`，以及网络层数 `l_num`。
  - 构建一个瓶颈层对象 `bottleneck`，用于对输入的节点和边特征进行初步线性变换与非线性激活处理。
  - 构建一个自定义的 `EGATLayer` 对象 `egat`，实现图注意力机制来更新节点和边特征。
  - 构建一个 `MLPPredictor` 对象 `pred`，用于最后的分类或回归预测任务。
  - 构建一个 `MergeLayer` 对象 `merge`，用于将多层特征融合为一层。

- 前向传播函数 `forward` 中：
  - 首先通过瓶颈层对输入节点特征 `h_in` 和边特征 `e_in` 进行处理，得到中间结果 `h_out` 和 `e_out`。
  - 接着使用 `for` 循环迭代 `l_num` 次，每次迭代调用自定义的 `EGATLayer` 更新节点和边特征，并在不是第一次迭代时（即除了第一层以外），将更新后的特征与之前保留的最终特征进行拼接（`th.cat`）以合并多层信息。
  - 循环结束后，使用合并层 `merge` 将最终得到的节点和边特征进行整合。
  - 最后，将整合后的边特征 `e_final` 输入到 `MLPPredictor` 进行预测，返回预测结果。

#### utils.py——数据集创建，结果评估

- `encode_onehot(labels)` 函数：
  - 输入：一个标签列表 `labels`，其中每个元素代表一个类别标签。
  - 输出：将输入的离散类别标签转换为独热编码（one-hot encoding）形式的二维数组。
- `normalize(mx)` 函数：
  - 输入：一个稀疏矩阵 `mx`（这里假设是 scipy.sparse 类型）。
  - 输出：对输入矩阵进行行归一化处理后的稀疏矩阵。
- 函数 `accuracy(output, labels)`：
  - 输入参数：`output` 是模型预测的结果（通常是一个包含每个类别概率的向量），`labels` 是实际标签。
  - 首先从输出中找到每个样本的最大概率对应的类别索引，并将其类型转换为与标签相同的类型。接着计算预测正确的元素个数，即将预测类别与真实标签进行比较并转换为浮点型布尔值，然后求和。最后，将正确预测的数量除以总样本数得到准确率。
- `load_data()`：
  - 该函数用于生成模拟数据集，并对数据进行预处理。
  - 首先随机生成一个有8个节点和30条边的图结构，并分别赋予节点和边20维特征。
  - 对于标签，使用 `encode_onehot` 函数将离散标签编码成独热编码形式，这里给出了一个示例标签列表。
  - 接着对节点和边的特征进行归一化处理。将数据集划分为训练集、验证集和测试集，通过 `idx_train`, `idx_val`, `idx_test` 分别记录这三个集合中的索引位置。
  - 将所有数据转换为 PyTorch 的 Tensor 类型以便于在 PyTorch 框架下进行计算。
  - 最后返回整个图对象、节点特征、边特征、标签以及划分好的训练、验证和测试集索引。

#### train.py——数据训练预测

- 创建了一个名为`model`的EGAT实例。参数说明如下：
  - `node_feats=node_features.shape[1]`：表示节点特征的维度，即每个节点有多少种特征。
  - `edge_feats=edge_features.shape[1]`：表示边特征的维度，即每条边有多少种特征。
  - `f_h=128`和`f_e=128`：可能分别代表隐藏层中节点特征和边特征的维度大小。
  - `lamda=args.lamda`：是一个超参数，用于调整模型中的某种权重或正则化项。
  - `num_heads=args.num_heads`：多头注意力机制中的头数，可以提升模型的学习能力和表达能力。
  - `dropout=args.dropout`：指定了一个丢弃概率，用于在训练过程中引入随机失活以防止过拟合。
  - `pred_hid=128`：预测层的隐藏单元数量。
  - `l_num=args.l_nums`：网络的层数或者说深度。
- `optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)`: 这行代码创建了一个Adam优化器实例，它将被用来更新模型的参数。其中，
  - `model.parameters()`：获取模型中所有可学习参数的集合。
  - `lr=args.lr`：学习率（learning rate），决定每次迭代时对模型参数更新的幅度。
  - `weight_decay=args.weight_decay`：L2正则化权重衰减系数，用于控制模型复杂度以避免过拟合。在Adam优化器中，这表现为权重衰减，也就是对模型权重矩阵进行惩罚，使其参数值不会过大。

















